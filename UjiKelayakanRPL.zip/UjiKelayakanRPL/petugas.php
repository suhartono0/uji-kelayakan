<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style type="text/css">

        
    </style>
    <?php
    include "config/koneksi.php"; //ini buat koneksi ke database di config

        //ini buat button simpan sekaligus save ke database
        if(isset($_POST['simpan'])){
            //ini untuk konek database ketika di simpn
            $sql = mysqli_query($con,"INSERT INTO tb_petugas (id_petugas,username,password,nama_petugas,id_level) values ('$_POST[id_petugas]','$_POST[username]','$_POST[password]','$_POST[nama_petugas]','$_POST[id_level]')");
            if($sql){
                echo "<script>alert('data berhasil disimpan');</script>";
            }
            else{
                echo "<script>alert('data gagal disimpan');</script>;";
            }
        }
        // ini untuk opsi delete hapus
        if(isset($_GET['delete'])){
            $sql = mysqli_query($con,"DELETE FROM tb_petugas WHERE id_petugas = '$_GET[id_petugas]'");
            if($sql){
                echo "<script>alert('data berhasil dihapus');document.location.href='http://localhost/UKL/ruang.php'</script>";
            }
            else{
                echo "<script>alert('data gagal dihapus');document.location.href='http://localhost/UKL/ruang.php'</script>";
            }
        }
        if(isset($_GET['edit'])){
            $sql = mysqli_query($con,"SELECT * FROM tb_petugas where id_petugas ='$_GET[id_petugas]'");
            $row_edit = mysqli_fetch_array($sql);
        }else{
            $row_edit=null;
        }
         if(isset($_POST['update'])){
             $sql = mysqli_query($con,"UPDATE tb_petugas set id_petugas = '$_POST[id_petugas]', username = '$_POST[username]' ,password = '$_POST[password]',nama_petugas = '$_POST[nama_petugas]',id_level = '$_POST[id_level]' WHERE id_petugas = '$_GET[id_petugas]'");
              if($sql){
                echo "<script>alert('data berhasil diupdate');
                document.location.href= http://localhost/UKL/ruang.php'</script>";
            }
            else{
                echo "<script>alert('data gagal diupdate');
                document.location.href= http://localhost/UKL/ruang.php'</script>";
            }
        }
    ?>
</head>
<body>
<!-- ini untuk tampilan form -->
<form method="post">
<table align="center" >
    <tr>
        <td>
            Id Petugas
        </td>
        <td>
            <input type="text" name="id_petugas" value="<?php echo $row_edit['id_petugas'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Username
        </td>
        <td>
            <input type="text" name="username" value="<?php echo $row_edit['username'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Passsword
        </td>
        <td>
            <input type="text" name="password" value="<?php echo $row_edit['password'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Nama Petugas
        </td>
        <td>
            <input type="text" name="nama_petugas" value="<?php echo $row_edit['nama_petugas'];?>">
        </td>
    </tr>
        <tr>
        <td>
            Id Level
        </td>
        <td>
            <input type="text" name="id_level" value="<?php echo $row_edit['id_level'];?>">
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <?php
                if(isset($_GET['edit'])){ 
            ?>
            <input type="submit" name="update" value="update">\
            <a href="petugas.php">batal</a>

            <?php }else{ ?>
                    <input type="submit" name="simpan" value="simpan">
            <?php } ?>
        </td>
    </tr>
</table>
<!-- ini untuk menampilkan database -->
</form>
<table border="1" align="center">
        <!-- ini tabel database -->
        
            <th>Id Petugas</th>
            <th>Username</th>
            <th>Password</th>
            <th>Nama Petugas</th>
            <th>Id Level</th>

        
        <!-- untuk memanggil databse dan menampilkan -->
        <?php
            $sql = mysqli_query($con,"SELECT * from tb_petugas");
            while($row = mysqli_fetch_array($sql)){
        ?>
        <tr>
                <td><?php echo $row['id_petugas']?></td>
                <td><?php echo $row['username']?></td>
                <td><?php echo $row['password']?></td>
                <td><?php echo $row['nama_petugas']?></td>
                <td><?php echo $row['id_level']?></td>

                <td><a href="?delete&id_petugas=<?php echo $row['id_petugas']?>"onClick="return confirm('Apakah anda yakin akan menghapus ini?')">hapus</a></td>
                <td><a href="?edit&id_petugas=<?php echo $row['id_petugas']?>"onClick="return confirm('Apakah anda yakin ingin mengedit ini?')">edit</a></td>
        </tr>
        <?php
            }
        ?>
</table>
</body>
</html>