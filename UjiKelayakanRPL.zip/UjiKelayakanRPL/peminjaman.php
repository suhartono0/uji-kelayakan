<?php

include "config/koneksi.php";
if(isset($_POST['simpan'])){
            $sql = mysqli_query($con,"INSERT INTO tb_peminjam (id_peminjam,tanggal_pinjam,tanggal_kembali,status_peminjam,id_pegawai) values ('$_POST[id_peminjam]','$_POST[tanggal_pinjam]','$_POST[tanggal_kembali]','$_POST[status_peminjam]','$_POST[id_pegawai]')");
            if($sql){
                echo "<script>alert('data berhasil disimpan');</script>";
            }
            else{
                echo "<script>alert('data gagal disimpan');</script>;";
            }
        }
  if(isset($_GET['hapus'])){
    $sql = "DELETE FROM tb_peminjam WHERE id_peminjam = '$_GET[id_peminjam]' ";
    $eksekusi = mysqli_query($con, $sql);
    echo "<script>alert('data berhasil terhapus');document.location.href='http://localhost/unj/dashboard.php?menu=peminjaman</script";

  }
  if(isset($_GET['edit'])){
    $sql ="SELECT * FROM tb_peminjam WHERE id_peminjam = '$_GET[id_peminjam]'";
    $eksekusi = mysqli_query($con, $sql);
    $edit = mysqli_fetch_array($eksekusi);
  }
?>
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Form peminjaman</h6>
            </div>
            <div class="card-body">
              <form method="post">
                <div class="form-group">
                  <div class="row">
                    <div class="col">
                      <input type="number" name="id_peminjam" value="<?php echo $edit['id_peminjam']?>" class="form-control" placeholder="id_peminjam">
                    </div>
                    <div class="col">
                      <input type=" " name="status_peminjam" value="<?php echo $edit['status_peminjam']?>" class="form-control" placeholder="Status Peminjam">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                <div class="row">
                    <div class="col">
                    <input type="date" name="tanggal_pinjam" value="<?php echo $edit['tanggal_pinjam']?>" class="form-control" placeholder="Tanggal Pinjam">
                    </div>
                    <div class="col">
                    <input type="date" name="tanggal_kembali" value="<?php echo $edit['tanggal_kembali']?>" class="form-control" placeholder="Tanggal Kembali">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <div class="col-6">
                      <input type=" " name="id_pegawai" value="<?php echo $edit['id_pegawai']?>" class="form-control" placeholder="id_pegawai">
                    </div>
                  </div>
                </div>
            <button type="submit" name="simpan" class="btn btn-primary">SIMPAN</button>
            </form>
            <br><br>
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Id Peminjam</th>
                      <th>Status Peminjam</th>
                      <th>Tanggal Pinjam</th>
                      <th>Tanggal Kembali</th>
                      <th>Id Pegawai</th>
                      <th colspan="2">Aksi</th>

                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      $sql = mysqli_query($con,"SELECT * FROM tb_peminjam");
                      while ($r=mysqli_fetch_array($sql)){  
                    ?>
                    <tr>
                      <td><?php echo $r['id_peminjam']?></td>
                      <td><?php echo $r['status_peminjam']?></td>
                      <td><?php echo $r['tanggal_pinjam']?></td>
                      <td><?php echo $r['tanggal_kembali']?></td>
                      <td><?php echo $r['id_pegawai']?></td>
                      <td><a onclick="return confirm('yakin?')" href="?menu=peminjaman&hapus&id_peminjam=<?php echo $r['id_peminjam']?>">HAPUS</a></td>
                      <td><a href="?menu=peminjaman&edit&id_peminjam=<?php echo $r['id_peminjam']?>">EDIT</a></td>

                    </tr>
                  <?php } ?>
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>

