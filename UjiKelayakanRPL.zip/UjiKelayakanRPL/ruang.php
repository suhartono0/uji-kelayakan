<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style type="text/css">

        
    </style>
    <?php
    include "config/koneksi.php"; //ini buat koneksi ke database di config

        //ini buat button simpan sekaligus save ke database
        if(isset($_POST['simpan'])){
            //ini untuk konek database ketika di simpn
            $sql = mysqli_query($con,"INSERT INTO tb_ruang (id_ruang,nama_ruang,kode_ruang,keterangan) values ('$_POST[id_ruang]','$_POST[nama_ruang]','$_POST[kode_ruang]','$_POST[keterangan]')");
            if($sql){
                echo "<script>alert('data berhasil disimpan');</script>";
            }
            else{
                echo "<script>alert('data gagal disimpan');</script>;";
            }
        }
        // ini untuk opsi delete hapus
        if(isset($_GET['delete'])){
            $sql = mysqli_query($con,"DELETE FROM tb_ruang WHERE id_ruang = '$_GET[id_ruang]'");
            if($sql){
                echo "<script>alert('data berhasil dihapus');document.location.href='http://localhost/UKL/ruang.php'</script>";
            }
            else{
                echo "<script>alert('data gagal dihapus');document.location.href='http://localhost/UKL/ruang.php'</script>";
            }
        }
        if(isset($_GET['edit'])){
            $sql = mysqli_query($con,"SELECT * FROM tb_ruang where id_ruang ='$_GET[id_ruang]'");
            $row_edit = mysqli_fetch_array($sql);
        }else{
            $row_edit=null;
        }
         if(isset($_POST['update'])){
             $sql = mysqli_query($con,"UPDATE tb_ruang set id_ruang = '$_POST[id_ruang]', nama_ruang = '$_POST[nama_ruang]' ,kode_ruang = '$_POST[kode_ruang]',keterangan = '$_POST[keterangan]' WHERE id_ruang = '$_GET[id_ruang]'");
              if($sql){
                echo "<script>alert('data berhasil diupdate');
                document.location.href= http://localhost/UKL/ruang.php'</script>";
            }
            else{
                echo "<script>alert('data gagal diupdate');
                document.location.href= http://localhost/UKL/ruang.php'</script>";
            }
        }
    ?>
</head>
<body>
<!-- ini untuk tampilan form -->
<form method="post">
<table align="center" >
    <tr>
        <td>
            Id Jenis
        </td>
        <td>
            <input type="text" name="id_ruang" value="<?php echo $row_edit['id_ruang'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Nama Jenis
        </td>
        <td>
            <input type="text" name="nama_ruang" value="<?php echo $row_edit['nama_ruang'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Kode Jenis
        </td>
        <td>
            <input type="text" name="kode_ruang" value="<?php echo $row_edit['kode_ruang'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Keterangan
        </td>
        <td>
            <input type="text" name="keterangan" value="<?php echo $row_edit['keterangan'];?>">
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <?php
                if(isset($_GET['edit'])){ 
            ?>
            <input type="submit" name="update" value="update">\
            <a href="ruang.php">batal</a>

            <?php }else{ ?>
                    <input type="submit" name="simpan" value="simpan">
            <?php } ?>
        </td>
    </tr>
</table>
<!-- ini untuk menampilkan database -->
</form>
<table border="1" align="center">
        <!-- ini tabel database -->
        
            <th>Id Jenis</th>
            <th>Nama Jenis</th>
            <th>Kode Jenis</th>
            <th>Keterangan</th>

        
        <!-- untuk memanggil databse dan menampilkan -->
        <?php
            $sql = mysqli_query($con,"SELECT * from tb_ruang");
            while($row = mysqli_fetch_array($sql)){
        ?>
        <tr>
                <td><?php echo $row['id_ruang']?></td>
                <td><?php echo $row['nama_ruang']?></td>
                <td><?php echo $row['kode_ruang']?></td>
                <td><?php echo $row['keterangan']?></td>

                <td><a href="?delete&id_ruang=<?php echo $row['id_ruang']?>"onClick="return confirm('Apakah anda yakin akan menghapus ini?')">hapus</a></td>
                <td><a href="?edit&id_ruang=<?php echo $row['id_ruang']?>"onClick="return confirm('Apakah anda yakin ingin mengedit ini?')">edit</a></td>
        </tr>
        <?php
            }
        ?>
</table>
</body>
</html>