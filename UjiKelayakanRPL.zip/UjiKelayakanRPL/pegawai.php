<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style type="text/css">

        
    </style>
    <?php
    include "config/koneksi.php"; //ini buat koneksi ke database di config

        //ini buat button simpan sekaligus save ke database
        if(isset($_POST['simpan'])){

            $sql = mysqli_query($con,"INSERT INTO tb_pegawai (id_pegawai,nama_pegawai,nip,alamat) values ('$_POST[id_pegawai]','$_POST[nama_pegawai]','$_POST[nip]','$_POST[alamat]')");
            if($sql){
                echo "<script>alert('data berhasil disimpan');</script>";
            }
            else{
                echo "<script>alert('data gagal disimpan');</script>;";
            }
        }
        // ini untuk opsi delete hapus
        if(isset($_GET['delete'])){
            $sql = mysqli_query($con,"DELETE FROM tb_pegawai WHERE id_pegawai = '$_GET[id_pegawai]'");
            if($sql){
                echo "<script>alert('data berhasil dihapus');document.location.href='http://localhost/UKL/pegawai.php'</script>";
            }
            else{
                echo "<script>alert('data gagal dihapus');document.location.href='http://localhost/UKL/pegawai.php'</script>";
            }
        }
        if(isset($_GET['edit'])){
            $sql = mysqli_query($con,"SELECT * FROM tb_pegawai where id_pegawai ='$_GET[id_pegawai]'");
            $row_edit = mysqli_fetch_array($sql);
        }else{
            $row_edit=null;
        }
         if(isset($_POST['update'])){
             $sql = mysqli_query($con,"UPDATE tb_pegawai set id_pegawai = '$_POST[id_pegawai]', nama_pegawai = '$_POST[nama_pegawai]' ,nip = '$_POST[nip]',alamat = '$_POST[alamat]' WHERE id_pegawai = '$_GET[id_pegawai]'");
              if($sql){
                echo "<script>alert('data berhasil diupdate');
                document.location.href= http://localhost/UKL/pegawai.php'</script>";
            }
            else{
                echo "<script>alert('data gagal diupdate');
                document.location.href= http://localhost/UKL/pegawai.php'</script>";
            }
        }
    ?>
</head>
<body>
<!-- ini untuk tampilan form -->
<form method="post">
<table align="center" >
    <tr>
        <td>
            Id Jenis
        </td>
        <td>
            <input type="text" name="id_pegawai" value="<?php echo $row_edit['id_pegawai'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Nama Jenis
        </td>
        <td>
            <input type="text" name="nama_pegawai" value="<?php echo $row_edit['nama_pegawai'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Kode Jenis
        </td>
        <td>
            <input type="text" name="nip" value="<?php echo $row_edit['nip'];?>">
        </td>
    </tr>
    <tr>
        <td>
            alamat
        </td>
        <td>
            <input type="text" name="alamat" value="<?php echo $row_edit['alamat'];?>">
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <?php
                if(isset($_GET['edit'])){ 
            ?>
            <input type="submit" name="update" value="update">\
            <a href="pegawai.php">batal</a>

            <?php }else{ ?>
                    <input type="submit" name="simpan" value="simpan">
            <?php } ?>
        </td>
    </tr>
</table>
<!-- ini untuk menampilkan database -->
</form>
<table border="1" align="center">
        <!-- ini tabel database -->
        
            <th>Id Jenis</th>
            <th>Nama Jenis</th>
            <th>Kode Jenis</th>
            <th>alamat</th>

        
        <!-- untuk memanggil databse dan menampilkan -->
        <?php
            $sql = mysqli_query($con,"SELECT * from tb_pegawai");
            while($row = mysqli_fetch_array($sql)){
        ?>
        <tr>
                <td><?php echo $row['id_pegawai']?></td>
                <td><?php echo $row['nama_pegawai']?></td>
                <td><?php echo $row['nip']?></td>
                <td><?php echo $row['alamat']?></td>

                <td><a href="?delete&id_pegawai=<?php echo $row['id_pegawai']?>"onClick="return confirm('Apakah anda yakin akan menghapus ini?')">hapus</a></td>
                <td><a href="?edit&id_pegawai=<?php echo $row['id_pegawai']?>"onClick="return confirm('Apakah anda yakin ingin mengedit ini?')">edit</a></td>
        </tr>
        <?php
            }
        ?>
</table>
</body>
</html>