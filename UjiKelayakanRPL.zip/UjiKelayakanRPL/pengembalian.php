<?php

include "config/koneksi.php";
if(isset($_POST['simpan'])){
            $sql = mysqli_query($con,"INSERT INTO tb_pengembalian (id_pengembalian,id_peminjam,id_pegawai,nama,kondisi) values ('$_POST[id_pengembalian]','$_POST[id_peminjam]','$_POST[id_pegawai]','$_POST[nama]','$_POST[kondisi]')");
            if($sql){
                echo "<script>alert('data berhasil disimpan');</script>";
            }
            else{
                echo "<script>alert('data gagal disimpan');</script>;";
            }
        }
  if(isset($_GET['hapus'])){
    $sql = "DELETE FROM tb_pengembalian WHERE id_pengembalian = '$_GET[id_pengembalian]' ";
    $eksekusi = mysqli_query($con, $sql);
    echo "<script>alert('data berhasil terhapus');document.location.href='http://localhost/UKL/dashboard.php?menu=pengembalian</script";


  }
  if(isset($_GET['edit'])){
    $sql ="SELECT * FROM tb_pengembalian WHERE id_pengembalian = '$_GET[id_pengembalian]'";
    $eksekusi = mysqli_query($con, $sql);
    $edit = mysqli_fetch_array($eksekusi);
  }
?>
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Form Pengembalian</h6>
            </div>
            <div class="card-body">
              <form method="post">
                <div class="form-group">
                  <div class="row">
                    <div class="col">
                      <input type="number" name="id_pengembalian" value="<?php echo $edit['id_pengembalian']?>" class="form-control" placeholder="Id Pengembalian">
                    </div>
                    <div class="col">
                      <input type="text" name="nama" value="<?php echo $edit['nama']?>" class="form-control" placeholder="Nama Barang">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                <div class="row">
                    <div class="col">
                    <input type="number" name="id_peminjam" value="<?php echo $edit['id_peminjam']?>" class="form-control" placeholder="Id Peminjam">
                    </div>
                    <div class="col">
                    <input type="number" name="id_pegawai" value="<?php echo $edit['id_pegawai']?>" class="form-control" placeholder="Id Pegawai">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <div class="col-6">
                      <input type="text" name="kondisi" value="<?php echo $edit['kondisi']?>" class="form-control" placeholder="kondisi">
                    </div>
                    <div class="col">
                    <input type="number" name="jumlah" value="<?php echo $edit['jumlah']?>" class="form-control" placeholder="Jumlah">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <div class="col-6">
                      <input type="text" name="keterangan" value="<?php echo $edit['keterangan']?>" class="form-control" placeholder="Keterangan">
                    </div>
                </div>
            </div>
            <button type="submit" name="simpan" class="btn btn-primary">SIMPAN</button>
            </form>
            <br><br>
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Id Pengmbalian</th>
                      <th>id_peminjam</th>
                      <th>id pegawai</th>
                      <th>nama</th>
                      <th>kondisi</th>
                      <th>jumlah</th>
                      <th>keterangan</th>
                      <th colspan="2">Aksi</th>

                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      $sql = mysqli_query($con,"SELECT * FROM tb_pengembalian");
                      while ($r=mysqli_fetch_array($sql)){  
                    ?>
                    <tr>
                      <td><?php echo $r['id_pengembalian']?></td>
                      <td><?php echo $r['nama']?></td>
                      <td><?php echo $r['id_peminjam']?></td>
                      <td><?php echo $r['id_pegawai']?></td>
                      <td><?php echo $r['kondisi']?></td>
                      <td><?php echo $r['jumlah']?></td>
                      <td><?php echo $r['keterangan']?></td>
                      <td><a onclick="return confirm('yakin?')" href="?menu=pengembalian&hapus&id_pengembalian=<?php echo $r['id_pengembalian']?>">HAPUS</a></td>
                      <td><a href="?menu=pengembalian&edit&id_pengembalian=<?php echo $r['id_pengembalian']?>">EDIT</a></td>
                    </tr>
                  <?php } ?>
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>

