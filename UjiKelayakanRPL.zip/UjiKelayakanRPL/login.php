<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<style type="text/css">
		*{
		box-sizing: border-box;
	}
		.contrainer{
		display: flex;
		flex-wrap: wrap;
		justify-content: center; 
	}
		.login-box{
		margin-top: 150px;
		flex-basis: 400px;
		background: #fff;
		padding: 20px;
	}
		.login-box h2{
		border-bottom: 1px solid #ccc;
		color: #555;
		text-align: center;
		padding-bottom: 20px;
		margin: 0 0 20px;
	}
		input,select{
		width: 100%;
		padding: 15px 20px;
		margin: 8px 0;
		border: 1px solid #ccc;
	}
	</style>
	<?php
		include "config/koneksi.php";
		if(isset($_POST ['login'])){

      	$sql = mysqli_query($con,"SELECT username,password from tb_petugas where username = '$_POST[username]' and password = '$_POST[password]'");

      	$cek_login=mysqli_num_rows($sql);

      	if($cek_login > 0){
      		echo "<script>alert('Selamat datang');document.location.href='dashboard.php'</script>";
      	}else{
      		echo "<script>alert('Maaf username atau kata sandi salah')</script>";
      	}

    }
	?>
</head>
</head>
<body>
	<div class="contrainer">
		<section class="login-box">
			<h2>Login</h2>
			<form method="post">
				<input type="text" placeholder="Username" name="username">
				<input type="password" placeholder="Password" name="password">
				<input type="submit" value="Login" name="login">
			</form>
		</section>
	</div>
</body>
</html>