<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style type="text/css">

        
    </style>
    <?php
    include "config/koneksi.php"; //ini buat koneksi ke database di config

        //ini buat button simpan sekaligus save ke database
        if(isset($_POST['simpan'])){
            //ini untuk konek database ketika di simpn
            $sql = mysqli_query($con,"INSERT INTO tb_detail_pinjam (id_detail_pinjam,id_inventaris,jumlah,id_peminjam) values ('$_POST[id_detail_pinjam]','$_POST[id_inventaris]','$_POST[jumlah]','$_POST[id_peminjam]')");
            if($sql){
                echo "<script>alert('data berhasil disimpan');</script>";
            }
            else{
                echo "<script>alert('data gagal disimpan');</script>;";
            }
        }
        // ini untuk opsi delete hapus
        if(isset($_GET['delete'])){
            $sql = mysqli_query($con,"DELETE FROM tb_detail_pinjam WHERE id_detail_pinjam = '$_GET[id_detail_pinjam]'");
            if($sql){
                echo "<script>alert('data berhasil dihapus');document.location.href='http://localhost/UKL/detailpeminjam.php'</script>";
            }
            else{
                echo "<script>alert('data gagal dihapus');document.location.href='http://localhost/UKL/detailpeminjam.php'</script>";
            }
        }
        if(isset($_GET['edit'])){
            $sql = mysqli_query($con,"SELECT * FROM tb_detail_pinjam where id_detail_pinjam ='$_GET[id_detail_pinjam]'");
            $row_edit = mysqli_fetch_array($sql);
        }else{
            $row_edit=null;
        }
         if(isset($_POST['update'])){
             $sql = mysqli_query($con,"UPDATE tb_detail_pinjam set id_detail_pinjam = '$_POST[id_detail_pinjam]', id_inventaris = '$_POST[id_inventaris]' ,jumlah = '$_POST[jumlah]',id_peminjam = '$_POST[id_peminjam]' WHERE id_detail_pinjam = '$_GET[id_detail_pinjam]'");
              if($sql){
                echo "<script>alert('data berhasil diupdate');
                document.location.href= http://localhost/UKL/detailpeminjam.php'</script>";
            }
            else{
                echo "<script>alert('data gagal diupdate');
                document.location.href= http://localhost/UKL/detailpeminjam.php'</script>";
            }
        }
    ?>
</head>
<body>
<!-- ini untuk tampilan form -->
<form method="post">
<table align="center" >
    <tr>
        <td>
            Id Detail Pinjam
        </td>
        <td>
            <input type="text" name="id_detail_pinjam" value="<?php echo $row_edit['id_detail_pinjam'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Id Inventaris
        </td>
        <td>
            <input type="text" name="id_inventaris" value="<?php echo $row_edit['id_inventaris'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Jumlah
        </td>
        <td>
            <input type="text" name="jumlah" value="<?php echo $row_edit['jumlah'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Id Peminjam
        </td>
        <td>
            <input type="text" name="id_peminjam" value="<?php echo $row_edit['id_peminjam'];?>">
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <?php
                if(isset($_GET['edit'])){ 
            ?>
            <input type="submit" name="update" value="update">\
            <a href="detailpeminjam.php">batal</a>

            <?php }else{ ?>
                    <input type="submit" name="simpan" value="simpan">
            <?php } ?>
        </td>
    </tr>
</table>
<!-- ini untuk menampilkan database -->
</form>
<table border="1" align="center">
        <!-- ini tabel database -->
        
            <th>Id Detail Pinjam</th>
            <th>Id Inventaris</th>
            <th>Jumlah</th>
            <th>Id Peminjam</th>

        
        <!-- untuk memanggil databse dan menampilkan -->
        <?php
            $sql = mysqli_query($con,"SELECT * from tb_detail_pinjam");
            while($row = mysqli_fetch_array($sql)){
        ?>
        <tr>
                <td><?php echo $row['id_detail_pinjam']?></td>
                <td><?php echo $row['id_inventaris']?></td>
                <td><?php echo $row['jumlah']?></td>
                <td><?php echo $row['id_peminjam']?></td>

                <td><a href="?delete&id_detail_pinjam=<?php echo $row['id_detail_pinjam']?>"onClick="return confirm('Apakah anda yakin akan menghapus ini?')">hapus</a></td>
                <td><a href="?edit&id_detail_pinjam=<?php echo $row['id_detail_pinjam']?>"onClick="return confirm('Apakah anda yakin ingin mengedit ini?')">edit</a></td>
        </tr>
        <?php
            }
        ?>
</table>
</body>
</html>