<?php

include "config/koneksi.php";
if(isset($_POST['simpan'])){
            $sql = mysqli_query($con,"INSERT INTO tb_inventaris (id_inventaris,nama_barang,kondisi,keterangan,jumlah,id_jenis,tanggal_register,id_ruang,kd_inventaris,id_petugas) values ('$_POST[id_inventaris]','$_POST[nama_barang]','$_POST[kondisi]','$_POST[keterangan]','$_POST[jumlah]','$_POST[id_jenis]','$_POST[tanggal_register]','$_POST[id_ruang]','$_POST[kd_inventaris]','$_POST[id_petugas]')");
            if($sql){
                echo "<script>alert('data berhasil disimpan');</script>";
            }
            else{
                echo "<script>alert('data gagal disimpan');</script>;";
            }
        }
  if(isset($_GET['hapus'])){
    $sql = "DELETE FROM tb_inventaris WHERE id_inventaris = '$_GET[id_inventaris]' ";
    $eksekusi = mysqli_query($con, $sql);
    echo "<script>alert('data berhasil terhapus');document.location.href='http://localhost/UKL/dashboard.php?menu=inventaris</script";


  }
  if(isset($_GET['edit'])){
    $sql ="SELECT * FROM tb_inventaris WHERE id_inventaris = '$_GET[id_inventaris]'";
    $eksekusi = mysqli_query($con, $sql);
    $edit = mysqli_fetch_array($eksekusi);
  }
?>
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Form inventaris</h6>
            </div>
            <div class="card-body">
              <form method="post">
                <div class="form-group">
                  <div class="row">
                    <div class="col">
                      <input type="number" name="id_inventaris" value="<?php echo $edit['id_inventaris']?>" class="form-control" placeholder="id_inventaris">
                    </div>
                    <div class="col">
                      <input type=" " name="keterangan" value="<?php echo $edit['keterangan']?>" class="form-control" placeholder="Status Peminjam">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                <div class="row">
                    <div class="col">
                    <input type="date" name="nama_barang" value="<?php echo $edit['nama_barang']?>" class="form-control" placeholder="Tanggal Pinjam">
                    </div>
                    <div class="col">
                    <input type="date" name="kondisi" value="<?php echo $edit['kondisi']?>" class="form-control" placeholder="Tanggal Kembali">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <div class="col-6">
                      <input type="number" name="jumlah" value="<?php echo $edit['jumlah']?>" class="form-control" placeholder="jumlah">
                    </div>
                    <div class="col">
                    <input type="date" name="id_jenis" value="<?php echo $edit['id_jenis']?>" class="form-control" placeholder="Tanggal Kembali">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <div class="col-6">
                      <input type="text" name="tanggal_register" value="<?php echo $edit['tanggal_register']?>" class="form-control" placeholder="tanggal_register">
                    </div>
                    <div class="col">
                    <input type="number" name="id_ruang" value="<?php echo $edit['id_ruang']?>" class="form-control" placeholder="Tanggal Kembali">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <div class="col-6">
                      <input type="text" name="kd_inventaris" value="<?php echo $edit['kd_inventaris']?>" class="form-control" placeholder="kd_inventaris">
                    </div>
                    <div class="col">
                    <input type="text" name="id_petugas" value="<?php echo $edit['id_petugas']?>" class="form-control" placeholder="Tanggal Kembali">
                    </div>
                  </div>
                </div>
            <button type="submit" name="simpan" class="btn btn-primary">SIMPAN</button>
            </form>
            <br><br>
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>id inventaris</th>
                      <th>nama barang</th>
                      <th>kondisi</th>
                      <th>keterangan</th>
                      <th>jumlah</th>
                      <th>id_jenis</th>
                      <th>tanggal register</th>
                      <th>id_ruang</th>
                      <th>kd inventaris</th>
                      <th>Id petugas</th>
                      <th colspan="2">Aksi</th>

                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      $sql = mysqli_query($con,"SELECT * FROM tb_inventaris");
                      while ($r=mysqli_fetch_array($sql)){  
                    ?>
                    <tr>
                      <td><?php echo $r['id_inventaris']?></td>
                      <td><?php echo $r['keterangan']?></td>
                      <td><?php echo $r['nama_barang']?></td>
                      <td><?php echo $r['kondisi']?></td>
                      <td><?php echo $r['jumlah']?></td>
                      <td><?php echo $r['id_jenis']?></td>
                      <td><?php echo $r['tanggal_register']?></td>
                      <td><?php echo $r['id_ruang']?></td>
                      <td><?php echo $r['kd_inventaris']?></td>
                      <td><?php echo $r['id_petugas']?></td>
                      <td><a onclick="return confirm('yakin?')" href="?menu=inventaris&hapus&id_inventaris=<?php echo $r['id_inventaris']?>">HAPUS</a></td>
                      <td><a href="?menu=inventaris&edit&id_inventaris=<?php echo $r['id_inventaris']?>">EDIT</a></td>

                    </tr>
                  <?php } ?>
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>

    