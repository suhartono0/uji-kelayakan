<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style type="text/css">


        
    </style>
    <?php
    include "config/koneksi.php"; //ini buat koneksi ke database di config

        //ini buat button simpan sekaligus save ke database
        if(isset($_POST['simpan'])){
            //ini untuk konek database ketika di simpn
            $sql = mysqli_query($con,"INSERT INTO tb_jenis (id_jenis,nama_jenis,kode_jenis,keterangan) values ('$_POST[id_jenis]','$_POST[nama_jenis]','$_POST[kode_jenis]','$_POST[keterangan]')");
            if($sql){
                echo "<script>alert('data berhasil disimpan');</script>";
            }
            else{
                echo "<script>alert('data gagal disimpan');</script>;";
            }
        }
        // ini untuk opsi delete hapus
        if(isset($_GET['delete'])){
            $sql = mysqli_query($con,"DELETE FROM tb_jenis WHERE id_jenis = '$_GET[id_jenis]'");
            if($sql){
                echo "<script>alert('data berhasil dihapus');document.location.href='http://localhost/UKL/jenis.php'</script>";
            }
            else{
                echo "<script>alert('data gagal dihapus');document.location.href='http://localhost/UKL/jenis.php'</script>";
            }
        }
        if(isset($_GET['edit'])){
            $sql = mysqli_query($con,"SELECT * FROM tb_jenis where id_jenis ='$_GET[id_jenis]'");
            $row_edit = mysqli_fetch_array($sql);
        }else{
            $row_edit=null;
        }
         if(isset($_POST['update'])){
             $sql = mysqli_query($con,"UPDATE tb_jenis set id_jenis = '$_POST[id_jenis]', nama_jenis = '$_POST[nama_jenis]' ,kode_jenis = '$_POST[kode_jenis]', keterangan = '$_POST[keterangan]' WHERE id_jenis = '$_GET[id_jenis]'");
              if($sql){
                echo "<script>alert('data berhasil diupdate');
                document.location.href= http://localhost/UKL/jenis.php'</script>";
            }
            else{
                echo "<script>alert('data gagal diupdate');
                document.location.href= http://localhost/UKL/jenis.php'</script>";
            }
        }
    ?>
</head>
<body>
<!-- ini untuk tampilan form -->
<form method="post">
<table align="center" >
    <tr>
        <td>
            Id Jenis
        </td>
        <td>
            <input type="text" name="id_jenis" value="<?php echo $row_edit['id_jenis'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Nama Jenis
        </td>
        <td>
            <input type="text" name="nama_jenis" value="<?php echo $row_edit['nama_jenis'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Kode Jenis
        </td>
        <td>
            <input type="text" name="kode_jenis" value="<?php echo $row_edit['kode_jenis'];?>">
        </td>
    </tr>
    <tr>
        <td>
            Keterangan
        </td>
        <td>
            <input type="text" name="keterangan" value="<?php echo $row_edit['kondisi'];?>">
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <?php
                if(isset($_GET['edit'])){ 
            ?>
            <input type="submit" name="update" value="update">\
            <a href="dokter.php">batal</a>

            <?php }else{ ?>
                    <input type="submit" name="simpan" value="simpan">
            <?php } ?>
        </td>
    </tr>
</table>
<!-- ini untuk menampilkan database -->
</form>
<table border="1" align="center">
        <!-- ini tabel database -->
        
            <th>Id Jenis</th>
            <th>Nama Jenis</th>
            <th>Kode Jenis</th>
            <th>Keterangan</th>

        
        <!-- untuk memanggil databse dan menampilkan -->
        <?php
            $sql = mysqli_query($con,"SELECT * from tb_jenis");
            while($row = mysqli_fetch_array($sql)){
        ?>
        <tr>
                <td><?php echo $row['id_jenis']?></td>
                <td><?php echo $row['nama_jenis']?></td>
                <td><?php echo $row['kode_jenis']?></td>
                <td><?php echo $row['keterangan']?></td>

                <td><a href="?delete&id_jenis=<?php echo $row['id_jenis']?>"onClick="return confirm('Apakah anda yakin akan menghapus ini?')">hapus</a></td>
                <td><a href="?edit&id_jenis=<?php echo $row['id_jenis']?>"onClick="return confirm('Apakah anda yakin ingin mengedit ini?')">edit</a></td>
        </tr>
        <?php
            }
        ?>
</table>
</body>
</html>